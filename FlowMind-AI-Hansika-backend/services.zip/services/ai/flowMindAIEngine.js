/**
 * services/ai/flowMindAIEngine.js
 *
 * Single public orchestration layer for FlowMind AI. Coordinates every AI
 * module in the correct sequence. Contains orchestration only — no Gemini
 * calls, prompts, AI reasoning, or business logic.
 */

"use strict";

const { extractInformation } = require("./informationExtractor");
const { detectWorkflow } = require("./workflowDetector");
const { planWorkflow } = require("./workflowPlanner");
const { generateDepartmentTasks } = require("./taskGenerator");
const { generateRecommendations } = require("./recommendationEngine");
const { generateDocuments } = require("./documentGenerator");
const { AIValidationError } = require("./aiErrors");
const {
  generateRequestId,
  logExecutionStart,
  logExecutionSuccess,
  logExecutionFailure,
} = require("./aiLogger");

// ─── Constants ────────────────────────────────────────────────────────────────

const ENGINE_NAME = "FlowMind AI";
const ENGINE_VERSION = "1.0";

const PIPELINE_STEPS = Object.freeze([
  "informationExtraction",
  "workflowDetection",
  "workflowPlanning",
  "departmentTaskGeneration",
  "recommendationGeneration",
  "documentGeneration",
]);

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Build orchestrator metadata block.
 * @returns {{ generatedAt: string, engine: string, version: string }}
 */
const buildMetadata = () => ({
  generatedAt: new Date().toISOString(),
  engine: ENGINE_NAME,
  version: ENGINE_VERSION,
});

/**
 * Validate processCommand input.
 * @param {unknown} command
 * @returns {string}
 */
const validateCommand = (command) => {
  if (typeof command !== "string" || command.trim() === "") {
    throw new AIValidationError("command must be a non-empty string.", { field: "command" });
  }

  return command.trim();
};

/**
 * Normalise a thrown error into a serialisable failure payload.
 * @param {unknown} error
 * @param {string} failedStep
 * @returns {object}
 */
const buildFailureResponse = (error, failedStep) => {
  const normalized = error instanceof Error
    ? {
      code: error.code || "AI_ERROR",
      message: error.message,
      retryable: Boolean(error.retryable),
      details: error.details || {},
    }
    : {
      code: "AI_ERROR",
      message: String(error),
      retryable: false,
      details: {},
    };

  return {
    success: false,
    failedStep,
    error: normalized,
    metadata: buildMetadata(),
  };
};

/**
 * Build the workflow execution summary from pipeline results.
 * @param {object} params
 * @param {object} params.extractedInformation
 * @param {object} params.workflowPlan
 * @param {object} params.departmentTasks
 * @param {object} params.recommendations
 * @param {object} params.documents
 * @returns {object}
 */
const buildSummary = ({
  extractedInformation,
  workflowPlan,
  departmentTasks,
  recommendations,
  documents,
}) => ({
  employee: extractedInformation.employeeName || null,
  role: extractedInformation.role || null,
  estimatedDuration: workflowPlan.estimatedDuration,
  departments: departmentTasks.totalDepartments,
  tasks: departmentTasks.totalTasks,
  documents: documents.documents.length,
  recommendations: recommendations.recommendations.length,
});

/**
 * Build the unified success response from pipeline results.
 * @param {object} params
 * @param {string} params.workflow
 * @param {object} params.informationExtraction
 * @param {object} params.workflowDetection
 * @param {object} params.workflowPlan
 * @param {object} params.departmentTasks
 * @param {object} params.recommendations
 * @param {object} params.documents
 * @returns {object}
 */
const buildSuccessResponse = ({
  workflow,
  informationExtraction,
  workflowDetection,
  workflowPlan,
  departmentTasks,
  recommendations,
  documents,
}) => ({
  success: true,
  workflow,
  summary: buildSummary({
    extractedInformation: informationExtraction.extractedInformation,
    workflowPlan,
    departmentTasks,
    recommendations,
    documents,
  }),
  informationExtraction,
  workflowDetection,
  workflowPlan,
  departmentTasks,
  recommendations,
  documents,
  metadata: buildMetadata(),
});

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Process a natural-language business command through the full FlowMind AI pipeline.
 *
 * @param {string} command - Unstructured business command
 * @returns {Promise<object>} Unified success or failure response
 */
const processCommand = async (command) => {
  const requestId = generateRequestId();
  let failedStep = PIPELINE_STEPS[0];

  logExecutionStart(requestId, {
    module: "flowMindAIEngine",
    commandLength: typeof command === "string" ? command.length : 0,
  });

  try {
    const trimmedCommand = validateCommand(command);

    failedStep = PIPELINE_STEPS[0];
    const informationExtraction = await extractInformation(trimmedCommand);

    failedStep = PIPELINE_STEPS[1];
    const workflowDetection = await detectWorkflow({
      command: trimmedCommand,
      extractedInformation: informationExtraction.extractedInformation,
    });

    const { workflow } = workflowDetection;

    failedStep = PIPELINE_STEPS[2];
    const workflowPlan = await planWorkflow({
      workflow,
      extractedInformation: informationExtraction.extractedInformation,
    });

    failedStep = PIPELINE_STEPS[3];
    const departmentTasks = await generateDepartmentTasks({
      workflow,
      extractedInformation: informationExtraction.extractedInformation,
      workflowPlan,
    });

    failedStep = PIPELINE_STEPS[4];
    const recommendations = await generateRecommendations({
      workflow,
      extractedInformation: informationExtraction.extractedInformation,
      workflowPlan,
      departmentTasks,
    });

    failedStep = PIPELINE_STEPS[5];
    const documents = await generateDocuments({
      workflow,
      extractedInformation: informationExtraction.extractedInformation,
      workflowPlan,
      departmentTasks,
      recommendations,
    });

    const result = buildSuccessResponse({
      workflow,
      informationExtraction,
      workflowDetection,
      workflowPlan,
      departmentTasks,
      recommendations,
      documents,
    });

    logExecutionSuccess(requestId, {
      module: "flowMindAIEngine",
      workflow: result.workflow,
      summary: result.summary,
    });

    return result;
  } catch (error) {
    const failure = buildFailureResponse(error, failedStep);

    logExecutionFailure(requestId, {
      module: "flowMindAIEngine",
      failedStep,
      code: failure.error.code,
      message: failure.error.message,
    });

    return failure;
  }
};

module.exports = {
  processCommand,
};
