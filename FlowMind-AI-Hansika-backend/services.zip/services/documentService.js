const { supabase } = require("../supabase/client");

class DocumentService {
  async createDocument(data) {
    const { data: result, error } = await supabase
      .from("documents")
      .insert([data])
      .select()
      .single();

    if (error) throw error;
    return result;
  }

  async updateDocument(id, data) {
    const { data: result, error } = await supabase
      .from("documents")
      .update({ ...data, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return result;
  }

  async deleteDocument(id) {
    const { data: result, error } = await supabase
      .from("documents")
      .delete()
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return result;
  }

  async getWorkflowDocuments(workflowId) {
    const { data: result, error } = await supabase
      .from("documents")
      .select("*")
      .eq("workflow_id", workflowId)
      .order("created_at", { ascending: false });

    if (error) throw error;
    return result;
  }

  async generateOfferLetter(workflowId, employeeDetails) {
    const documentName = `Offer_Letter_${employeeDetails.employee_name.replace(/\s+/g, "_")}.pdf`;
    const documentData = {
      workflow_id: workflowId,
      document_name: documentName,
      document_type: "Offer Letter",
      file_url: employeeDetails.file_url || `https://storage.flowmindai.local/documents/offers/${Date.now()}_offer.pdf`,
      generated_by: "AI HR Agent",
      status: "Approved"
    };

    const doc = await this.createDocument(documentData);

    // Log the document generation
    await supabase.from("workflow_logs").insert([
      {
        workflow_id: workflowId,
        action: "Document Generated",
        message: `Offer Letter "${documentName}" has been generated.`,
        performed_by: "AI HR Agent"
      }
    ]);

    return doc;
  }

  async generateAppointmentLetter(workflowId, employeeDetails) {
    const documentName = `Appointment_Letter_${employeeDetails.employee_name.replace(/\s+/g, "_")}.pdf`;
    const documentData = {
      workflow_id: workflowId,
      document_name: documentName,
      document_type: "Appointment Letter",
      file_url: employeeDetails.file_url || `https://storage.flowmindai.local/documents/appointments/${Date.now()}_appointment.pdf`,
      generated_by: "AI HR Agent",
      status: "Approved"
    };

    const doc = await this.createDocument(documentData);

    // Log the document generation
    await supabase.from("workflow_logs").insert([
      {
        workflow_id: workflowId,
        action: "Document Generated",
        message: `Appointment Letter "${documentName}" has been generated.`,
        performed_by: "AI HR Agent"
      }
    ]);

    return doc;
  }

  async generateWelcomeLetter(workflowId, employeeDetails) {
    const documentName = `Welcome_Letter_${employeeDetails.employee_name.replace(/\s+/g, "_")}.pdf`;
    const documentData = {
      workflow_id: workflowId,
      document_name: documentName,
      document_type: "Welcome Letter",
      file_url: employeeDetails.file_url || `https://storage.flowmindai.local/documents/welcome/${Date.now()}_welcome.pdf`,
      generated_by: "AI HR Agent",
      status: "Approved"
    };

    const doc = await this.createDocument(documentData);

    // Log the document generation
    await supabase.from("workflow_logs").insert([
      {
        workflow_id: workflowId,
        action: "Document Generated",
        message: `Welcome Letter "${documentName}" has been generated.`,
        performed_by: "AI HR Agent"
      }
    ]);

    return doc;
  }

  async getDocumentStatus(id) {
    const { data: result, error } = await supabase
      .from("documents")
      .select("status")
      .eq("id", id)
      .single();

    if (error) throw error;
    return result ? result.status : null;
  }

  async downloadDocument(id) {
    const { data: result, error } = await supabase
      .from("documents")
      .select("document_name, file_url")
      .eq("id", id)
      .single();

    if (error) throw error;
    return result;
  }
}

module.exports = new DocumentService();
