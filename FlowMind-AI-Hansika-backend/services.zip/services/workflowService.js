const { supabase } = require("../supabase/client");

class WorkflowService {
  async createWorkflow(data) {
    // Set initial values if not provided
    const workflowData = {
      ...data,
      workflow_status: data.workflow_status || "In Progress",
      progress_percentage: data.progress_percentage || 0,
      started_at: new Date().toISOString()
    };

    // 1. Create Workflow
    const { data: workflow, error: workflowError } = await supabase
      .from("workflows")
      .insert([workflowData])
      .select()
      .single();

    if (workflowError) throw workflowError;

    try {
      // 2. Query existing departments to map tasks if possible
      const { data: departments } = await supabase
        .from("departments")
        .select("id, department_name, department_code")
        .eq("company_id", workflow.company_id);

      const findDeptId = (nameOrCode) => {
        if (!departments || departments.length === 0) return null;
        const lower = nameOrCode.toLowerCase();
        const found = departments.find(
          (d) =>
            d.department_name.toLowerCase().includes(lower) ||
            d.department_code.toLowerCase().includes(lower)
        );
        return found ? found.id : departments[0].id; // Fallback to first department
      };

      const hrDeptId = findDeptId("HR");
      const itDeptId = findDeptId("IT");
      const mgmtDeptId = findDeptId("Management") || findDeptId("Admin");

      // 3. Generate Initial Tasks (7 standard steps)
      const initialTasks = [
        {
          workflow_id: workflow.id,
          department_id: hrDeptId,
          task_name: "HR Verification",
          task_description: "Initial profile and eligibility check",
          execution_order: 1,
          priority: "High",
          status: "In Progress"
        },
        {
          workflow_id: workflow.id,
          department_id: hrDeptId,
          task_name: "Document Upload",
          task_description: "Employee uploads required documents (Aadhar, PAN, degree, etc.)",
          execution_order: 2,
          priority: "High",
          status: "Pending"
        },
        {
          workflow_id: workflow.id,
          department_id: itDeptId,
          task_name: "AI Verification",
          task_description: "AI validates uploaded document authenticity",
          execution_order: 3,
          priority: "Medium",
          status: "Pending"
        },
        {
          workflow_id: workflow.id,
          department_id: mgmtDeptId,
          task_name: "Manager Approval",
          task_description: "Department manager reviews and approves candidate",
          execution_order: 4,
          priority: "Medium",
          status: "Pending"
        },
        {
          workflow_id: workflow.id,
          department_id: itDeptId,
          task_name: "IT Setup",
          task_description: "Laptop, accounts, and tools provisioning",
          execution_order: 5,
          priority: "High",
          status: "Pending"
        },
        {
          workflow_id: workflow.id,
          department_id: hrDeptId,
          task_name: "Orientation",
          task_description: "Company culture and policy orientation session",
          execution_order: 6,
          priority: "Low",
          status: "Pending"
        },
        {
          workflow_id: workflow.id,
          department_id: mgmtDeptId,
          task_name: "Completed",
          task_description: "Onboarding process finalized and signed off",
          execution_order: 7,
          priority: "Low",
          status: "Pending"
        }
      ];

      const { error: tasksError } = await supabase
        .from("tasks")
        .insert(initialTasks);

      if (tasksError) console.error("Error creating initial tasks:", tasksError);

      // 4. Generate Initial Workflow Logs
      const initialLogs = [
        {
          workflow_id: workflow.id,
          action: "Created",
          message: `Workflow ${workflow.workflow_number} has been initialized successfully.`,
          performed_by: "System"
        },
        {
          workflow_id: workflow.id,
          action: "Tasks Generated",
          message: "Standard 7-step execution tasks generated.",
          performed_by: "System"
        }
      ];

      const { error: logsError } = await supabase
        .from("workflow_logs")
        .insert(initialLogs);

      if (logsError) console.error("Error creating initial logs:", logsError);

      // 5. Generate Initial Recommendations
      const initialRecommendations = [
        {
          workflow_id: workflow.id,
          recommendation_type: "Process Efficiency",
          recommendation_text: "Ensure HR Verification is completed within the first 24 hours to expedite downstream steps.",
          confidence_percentage: 95,
          status: "Active"
        },
        {
          workflow_id: workflow.id,
          recommendation_type: "Resource Management",
          recommendation_text: "Pre-order default laptop models for IT Setup to avoid procurement delays.",
          confidence_percentage: 88,
          status: "Active"
        }
      ];

      const { error: recsError } = await supabase
        .from("recommendations")
        .insert(initialRecommendations);

      if (recsError) console.error("Error creating initial recommendations:", recsError);
    } catch (e) {
      // Log error but don't fail the workflow creation itself
      console.error("Workflow automation error:", e);
    }

    return workflow;
  }

  async updateWorkflow(id, data) {
    const updateData = {
      ...data,
      updated_at: new Date().toISOString()
    };

    if (data.workflow_status === "Completed") {
      updateData.completed_at = new Date().toISOString();
      updateData.progress_percentage = 100;
    }

    const { data: result, error } = await supabase
      .from("workflows")
      .update(updateData)
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return result;
  }

  async deleteWorkflow(id) {
    const { data: result, error } = await supabase
      .from("workflows")
      .delete()
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return result;
  }

  async getWorkflows() {
    const { data: result, error } = await supabase
      .from("workflows")
      .select("*, workflow_types(workflow_code, workflow_name), workflow_definitions(display_name, version)")
      .order("created_at", { ascending: false });

    if (error) throw error;
    return result;
  }

  async getWorkflowById(id) {
    const { data: result, error } = await supabase
      .from("workflows")
      .select("*, workflow_types(workflow_code, workflow_name), workflow_definitions(display_name, version)")
      .eq("id", id)
      .single();

    if (error) throw error;
    return result;
  }

  async getWorkflowStatus(id) {
    const { data: result, error } = await supabase
      .from("workflows")
      .select("workflow_status")
      .eq("id", id)
      .single();

    if (error) throw error;
    return result ? result.workflow_status : null;
  }

  async getWorkflowProgress(id) {
    const { data: result, error } = await supabase
      .from("workflows")
      .select("progress_percentage")
      .eq("id", id)
      .single();

    if (error) throw error;
    return result ? result.progress_percentage : null;
  }

  async getWorkflowHistory(id) {
    const { data: result, error } = await supabase
      .from("workflow_logs")
      .select("*")
      .eq("workflow_id", id)
      .order("created_at", { ascending: false });

    if (error) throw error;
    return result;
  }

  async getWorkflowPriority(id) {
    const { data: result, error } = await supabase
      .from("workflows")
      .select("priority")
      .eq("id", id)
      .single();

    if (error) throw error;
    return result ? result.priority : null;
  }

  async getWorkflowTimeline(id) {
    const { data: result, error } = await supabase
      .from("tasks")
      .select("*, departments(department_name)")
      .eq("workflow_id", id)
      .order("execution_order", { ascending: true });

    if (error) throw error;
    return result;
  }

  async getWorkflowSummary(id) {
    const { data: workflow, error: workflowError } = await this.getWorkflowById(id);
    if (workflowError) throw workflowError;

    const { data: tasks, error: tasksError } = await supabase
      .from("tasks")
      .select("status")
      .eq("workflow_id", id);

    if (tasksError) throw tasksError;

    const totalTasks = tasks ? tasks.length : 0;
    const completedTasks = tasks ? tasks.filter((t) => t.status === "Completed").length : 0;
    const activeTask = tasks ? tasks.find((t) => t.status === "In Progress") : null;

    return {
      workflow_id: workflow.id,
      workflow_number: workflow.workflow_number,
      status: workflow.workflow_status,
      progress: workflow.progress_percentage,
      priority: workflow.priority,
      task_completion: `${completedTasks}/${totalTasks}`,
      current_stage: activeTask ? activeTask.task_name : "N/A",
      started_at: workflow.started_at,
      completed_at: workflow.completed_at
    };
  }
}

module.exports = new WorkflowService();
